package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    ArrayList<RepositoryVO>  repositoryVOArrayList =new ArrayList<>();
    private Adapter adapter;
    private RecyclerView cars_recyclerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cars_recyclerview=(RecyclerView)findViewById(R.id.cars_recyclerview);
        cars_recyclerview.setLayoutManager(new LinearLayoutManager(this));

        getCarsResponse();

    }

    private void getCarsResponse() {
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl("https://api.github.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        MainInterface requestInteface=retrofit.create(MainInterface.class);
        Call<List<RepositoryVO>> call=requestInteface.getCarsJson();



        call.enqueue(new Callback<List<RepositoryVO>>() {
            @Override
            public void onResponse(Call<List<RepositoryVO>> call, Response<List<RepositoryVO>> response) {
                repositoryVOArrayList=new ArrayList<>(response.body());
                adapter=new Adapter(MainActivity.this,repositoryVOArrayList);
                cars_recyclerview.setAdapter(adapter);

            }

            @Override
            public void onFailure(Call<List<RepositoryVO>> call, Throwable t) {

            }
        });
    }

}
