package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private ArrayList<RepositoryVO> repositoryVO=new ArrayList<>();
    private Context context;


    public Adapter(Context context, ArrayList<RepositoryVO> repositoryVO) {
        this.repositoryVO=repositoryVO;
        this.context=context;
    }

    @NonNull
    @Override
    public Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cars_list_item,viewGroup,false);
        return new Adapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder viewHolder, int i) {
        viewHolder.car_name.setText(repositoryVO.get(i).getName());


        final RepositoryVO repositoryVO = this.repositoryVO.get(i);
        viewHolder.car_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context,CustomDetail.class);
                Log.d("modal", "test"+repositoryVO.getLogin());
                intent.putExtra("carName",repositoryVO.getName());
                intent.putExtra("carLogin",repositoryVO.getLogin());
                intent.putExtra("carFullName",repositoryVO.getFull_name());



                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return repositoryVO.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        //private ImageView car_image;
        private TextView car_name,car_desc;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            //car_image=(ImageView)itemView.findViewById(R.id.car_image);
            car_name=(TextView) itemView.findViewById(R.id.car_name);
            car_desc=(TextView)itemView.findViewById(R.id.car_desc);
        }
    }
}

