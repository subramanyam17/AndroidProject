package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.TextView;

public class CustomDetail extends AppCompatActivity {
    TextView name;
    TextView login;
    TextView fullname;
    TextView owner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_detail);
        name=findViewById(R.id.name);
        login=findViewById(R.id.login);
        fullname=findViewById(R.id.fullname);
        owner=findViewById(R.id.owner);



        Intent intent=getIntent();
        final String carName = intent.getStringExtra("carName");
        final String carLogin = intent.getStringExtra("carLogin");
        final String carFullName = intent.getStringExtra("carFullName");
        final String carOwner = intent.getStringExtra("carOwner");


        name.setText(carName);
        login.setText(carLogin);
        fullname.setText(carFullName);
    }
}